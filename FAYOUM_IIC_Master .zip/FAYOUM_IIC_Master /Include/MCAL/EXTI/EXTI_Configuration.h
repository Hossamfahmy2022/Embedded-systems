/****************************************************/
/*   AUTHOR      : Abdelrahman Hossam               */
/*   Description : EXTI DRIVER                      */
/*   DATE        : 18 AGU 2021                      */
/*   VERSION     : V01                              */
/****************************************************/

#ifndef INCLUDE_MCAL_EXTI_EXTI_CONFIGURATION_H_
#define INCLUDE_MCAL_EXTI_EXTI_CONFIGURATION_H_



#endif /* INCLUDE_MCAL_EXTI_EXTI_CONFIGURATION_H_ */
