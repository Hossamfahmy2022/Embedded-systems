/*
 * SPI_Configuration.h
 *
 *  Created on: Aug 26, 2021
 *      Author: Abdelrahman Hossam
 */

#ifndef INCLUDE_MCAL_SPI_SPI_CONFIGURATION_H_
#define INCLUDE_MCAL_SPI_SPI_CONFIGURATION_H_

/*
 * options :
 * SPI_u8_MASTER_MODE
 * SPI_u8_SLAVE_MODE
 * */
#define SPI_u8_MODE  SPI_u8_MASTER_MODE

#endif /* INCLUDE_MCAL_SPI_SPI_CONFIGURATION_H_ */
