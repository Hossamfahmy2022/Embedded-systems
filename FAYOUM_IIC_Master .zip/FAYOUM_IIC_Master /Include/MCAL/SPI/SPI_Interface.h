/*
 * SPI_Interface.h
 *
 *  Created on: Aug 26, 2021
 *      Author: Abdelrahman Hossam
 */

#ifndef INCLUDE_MCAL_SPI_SPI_INTERFACE_H_
#define INCLUDE_MCAL_SPI_SPI_INTERFACE_H_

u8 MSPI_u8TransReceive (u8 copy_u8Data);
void MSPI_voidInit (void);

#endif /* INCLUDE_MCAL_SPI_SPI_INTERFACE_H_ */
