/*
 * SPI_Private.h
 *
 *  Created on: Aug 26, 2021
 *      Author: Abdelrahman Hossam
 */

#ifndef INCLUDE_MCAL_SPI_SPI_PRIVATE_H_
#define INCLUDE_MCAL_SPI_SPI_PRIVATE_H_

#define SPI_u8_SPDR_REG    *((volatile u8 *)0x2F)
#define SPI_u8_SPSR_REG    *((volatile u8 *)0x2E)
#define SPI_u8_SPCR_REG    *((volatile u8 *)0x2D)


#define SPI_u8_MASTER_MODE    0
#define SPI_u8_SLAVE_MODE     1


#endif /* INCLUDE_MCAL_SPI_SPI_PRIVATE_H_ */
