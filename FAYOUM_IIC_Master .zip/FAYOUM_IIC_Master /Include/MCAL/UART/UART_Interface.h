/*
 * UART_Interface.h
 *
 *  Created on: Aug 25, 2021
 *      Author: Abdelrahman Hossam
 */

#ifndef INCLUDE_MCAL_UART_UART_INTERFACE_H_
#define INCLUDE_MCAL_UART_UART_INTERFACE_H_



#endif /* INCLUDE_MCAL_UART_UART_INTERFACE_H_ */
