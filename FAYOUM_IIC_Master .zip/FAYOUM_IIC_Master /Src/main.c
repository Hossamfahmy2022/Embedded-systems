/****************************************************/
/*   AUTHOR      : Abdelrahman Hossam               */
/*   Description : EXTI DRIVER                      */
/*   DATE        : 18 AGU 2021                      */
/*   VERSION     : V01                              */
/****************************************************/

/****************************************************/
/* Library Directives							    */
/****************************************************/
#define F_CPU 8000000UL
#include <util/delay.h>
#include "../LIB/STD_TYPES.h"
#include "../LIB/BIT_MATH.h"

/****************************************************/
/* DIO Directives								    */
/****************************************************/
#include "../Include/MCAL/DIO/DIO_Interface.h"
#include "../Include/MCAL/DIO/DIO_Private.h"
#include "../Include/MCAL/DIO/DIO_Configuration.h"

#include "../Include/MCAL/UART/UART_Interface.h"
#include "../Include/MCAL/UART/UART_Private.h"
#include "../Include/MCAL/UART/UART_Configuration.h"


#include "../Include/MCAL/SPI/SPI_Interface.h"
#include "../Include/MCAL/SPI/SPI_Private.h"
#include "../Include/MCAL/SPI/SPI_Configuration.h"

#include "../Include/I2c.h"
#include "../Include/eeprom.h"

//
//int main(void)
//{
//
//MDIO_voidInit();
//
//u8 received_data=0;
//
//	i2c_init_slave();
//	//check slave address with write req
//
//	while (1)
//	{
//
//		received_data=i2c_read_byte();
//
//
//		if(received_data==0x03)
//		{
//			MDIO_voidSetPinValue(DIO_u8_PORTA, DIO_u8_PIN0,DIO_u8_HIGH);
//		}
//		else
//		{
//			MDIO_voidSetPinValue(DIO_u8_PORTA, DIO_u8_PIN0,DIO_u8_LOW);
//		}
//
//
//	}
//}


//int main(void)
//{
//	i2c_init_master();
//
//
//
//	while (1)
//	{
//			i2c_start();
//			_delay_ms(10);
//			i2c_send_slave_address_with_write_req(1);
//			_delay_ms(10);
//			i2c_slave_write_byte(0x03);
//			_delay_ms(10);
//			i2c_stop();
//			_delay_ms(10);
//	}
//}


u8 x,v;
int main(void)
{
	MDIO_voidInit();

	EEpromInit();

	_delay_ms(500);

	EEpromWriteByte(1,50);
	_delay_ms(500);

	EEpromWriteByte(2,100);
	_delay_ms(500);


	u8 v1 = EEpromReadByte(1);
	u8 v2 = EEpromReadByte(2);

	_delay_ms(1000);
	while (1)
	{
		if ((v1==50) && (v2==100))
		{
			MDIO_voidSetPinValue(DIO_u8_PORTA, DIO_u8_PIN0,DIO_u8_HIGH);
		}
	}
}

