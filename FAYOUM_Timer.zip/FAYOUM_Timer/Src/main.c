/****************************************************/
/*   AUTHOR      : Abdelrahman Hossam               */
/*   Description : EXTI DRIVER                      */
/*   DATE        : 18 AGU 2021                      */
/*   VERSION     : V01                              */
/****************************************************/

/****************************************************/
/* Library Directives							    */
/****************************************************/
#define F_CPU 8000000UL
#include <util/delay.h>
#include "../LIB/STD_TYPES.h"
#include "../LIB/BIT_MATH.h"

/****************************************************/
/* DIO Directives								    */
/****************************************************/
#include "../Include/MCAL/DIO/DIO_Interface.h"
#include "../Include/MCAL/DIO/DIO_Private.h"
#include "../Include/MCAL/DIO/DIO_Configuration.h"

#include "../Include/MCAL/EXTI/EXTI_Interface.h"
#include "../Include/MCAL/EXTI/EXTI_Private.h"
#include "../Include/MCAL/EXTI/EXTI_Configuration.h"

#include "../Include/MCAL/GBI/GPI_Interface.h"

#include "../Include/MCAL/TIMER0/TIMER0_Interface.h"
#include "../Include/MCAL/TIMER0/TIMER0_Private.h"
#include "../Include/MCAL/TIMER0/TIMER0_Configuration.h"

void ToggleLed(void);

void (main)(void)
{
	MDIO_voidInit();
//	MTIMERS_voidTimer1Init();
//	MTIMERS_voidTimer0Init();
//	MTIMERS_voidTimer0CTCSetCallBack(&ToggleLed);
	while (1)
	{
		WDT_voidEnable();
		MDIO_voidSetPinValue(DIO_u8_PORTA,DIO_u8_PIN0,DIO_u8_HIGH);
		_delay_ms(1000);
		MDIO_voidSetPinValue(DIO_u8_PORTA,DIO_u8_PIN0,DIO_u8_LOW);
		while(1);
		WDT_voidDisable();
	}

}

void ToggleLed(void)
{
	static u8 flag=0;
	if (flag==0)
	{
		MDIO_voidSetPinValue(DIO_u8_PORTA,DIO_u8_PIN0,DIO_u8_HIGH);
		flag=1;
	}
	else
	{
		MDIO_voidSetPinValue(DIO_u8_PORTA,DIO_u8_PIN0,DIO_u8_LOW);
		flag=0;
	}
}
